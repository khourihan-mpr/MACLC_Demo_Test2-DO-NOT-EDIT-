#This is a test function for demonstration purposes only.
def test_fn(x,y):
    return (x + 2*y)