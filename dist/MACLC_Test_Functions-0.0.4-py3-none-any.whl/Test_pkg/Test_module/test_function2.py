#This is a second test function for demonstration purposes
def test_fn2(x,y):
    return (x + y)

def test_fn2_add(x,y,z):
    return (x + y + z)